TSLP Deployment (Render-ready)
=============================

This package is ready to push to GitHub and deploy on Render.

Files:
- app.py               # Flask backend + alert endpoints
- requirements.txt
- render.yaml          # Render service + cron configuration
- static/tslp_dashboard_live.html
- static/tslp_data.json
- data/alerts.json     # created at runtime

Quick local test:
-----------------
1. Create venv, install deps:
   python3 -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt

2. Run locally (mock mode):
   export USE_MOCK=1
   python app.py
   Visit http://localhost:5000/

Register an alert (example):
----------------------------
POST /api/alert
Content-Type: application/json
{
  "type": "threshold",
  "direction": "above",
  "value": 15.5,
  "notify": {"email":"you@example.com", "sms":"+15551234567"}
}

Evaluate alerts (manually/test):
-------------------------------
POST /api/evaluate
This will read the current value from static/tslp_data.json and send notifications if thresholds hit.
In Render you can enable the cron job (render.yaml) which will POST to /api/evaluate on a schedule.

Production notes:
-----------------
- Configure SMTP: SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS, EMAIL_FROM
- Configure Twilio (optional): TWILIO_SID, TWILIO_TOKEN, TWILIO_FROM
- When ready to use real market data, set USE_MOCK=0 and configure a real data provider + API key (ALPHA_VANTAGE_KEY etc.) in env vars.
- Add a domain, enable HTTPS in Render dashboard.

Security & costs:
- Twilio SMS costs per message; Render has a free tier but may incur charges depending on usage.
- Keep API keys in Render environment variables (do not commit them to Git).
