import os, json, smtplib, traceback
from flask import Flask, request, jsonify, send_from_directory
from datetime import datetime
from email.message import EmailMessage

try:
    from twilio.rest import Client as TwilioClient
except Exception:
    TwilioClient = None

app = Flask(__name__, static_folder="static", static_url_path="/static")

DATA_DIR = "data"
ALERTS_FILE = os.path.join(DATA_DIR, "alerts.json")
os.makedirs(DATA_DIR, exist_ok=True)

# Utility: load/save alerts
def load_alerts():
    if not os.path.exists(ALERTS_FILE):
        return []
    with open(ALERTS_FILE, "r", encoding="utf-8") as f:
        return json.load(f)

def save_alerts(alerts):
    with open(ALERTS_FILE, "w", encoding="utf-8") as f:
        json.dump(alerts, f, indent=2)

# Serve dashboard
@app.route("/")
def index():
    return send_from_directory(app.static_folder, "tslp_dashboard_live.html")

# Simple API returning mock or real data depending on env
@app.route("/api/tslp")
def api_tslp():
    use_mock = os.getenv("USE_MOCK", "1") == "1"
    if use_mock:
        with open(os.path.join(app.static_folder, "tslp_data.json"), "r", encoding="utf-8") as f:
            return jsonify(json.load(f))
    return jsonify({"error":"real API not configured"})

# Register an alert
# POST /api/alert with JSON: {"type":"threshold","symbol":"TSLP","direction":"above","value":15.5,"notify":{"email":"you@example.com"}} 
@app.route("/api/alert", methods=["POST"])
def create_alert():
    body = request.get_json() or {}
    required = ["type","direction","value","notify"]
    if not all(k in body for k in required):
        return jsonify({"error":"missing fields","required":required}), 400
    alerts = load_alerts()
    alert = {
        "id": int(datetime.utcnow().timestamp()*1000),
        "type": body.get("type"),
        "symbol": body.get("symbol","TSLP"),
        "direction": body.get("direction"),
        "value": float(body.get("value")),
        "notify": body.get("notify"),
        "created_at": datetime.utcnow().isoformat()
    }
    alerts.append(alert)
    save_alerts(alerts)
    return jsonify({"ok":True,"alert":alert})

# List alerts
@app.route("/api/alerts")
def list_alerts():
    return jsonify(load_alerts())

# Remove alert
@app.route("/api/alert/<int:alert_id>", methods=["DELETE"])
def delete_alert(alert_id):
    alerts = load_alerts()
    new = [a for a in alerts if a.get("id")!=alert_id]
    save_alerts(new)
    return jsonify({"ok":True})

# Evaluate alerts: fetch current value and send notifications for triggered alerts
# This endpoint is suitable for a cron job (Render Cron, GitHub Actions, or external scheduler)
@app.route("/api/evaluate", methods=["POST","GET"])
def evaluate_alerts():
    # Load current value from API
    try:
        # Use local mock file for now
        with open(os.path.join(app.static_folder, "tslp_data.json"), "r", encoding="utf-8") as f:
            data = json.load(f)
        current = float(data.get("current_value",0))
    except Exception as e:
        return jsonify({"error":"failed to load current value","details":str(e)}), 500

    alerts = load_alerts()
    triggered = []
    remaining = []
    for a in alerts:
        direction = a.get("direction")
        threshold = float(a.get("value",0))
        hit = False
        if direction=="above" and current>threshold:
            hit = True
        if direction=="below" and current<threshold:
            hit = True
        if hit:
            # send notifications
            notify = a.get("notify",{})
            try:
                send_notifications(notify, a, current)
                triggered.append({"alert":a,"current":current})
            except Exception as e:
                triggered.append({"alert":a,"current":current,"error":str(e)})
        else:
            remaining.append(a)

    # Optionally, remove one-time alerts (keeps only remaining)
    # save_alerts(remaining)  # Uncomment to auto-delete triggered alerts
    return jsonify({"evaluated_at": datetime.utcnow().isoformat(), "current": current, "triggered": triggered})

# Notification helpers (SMTP and Twilio)
def send_notifications(notify, alert, current):
    errors = []
    # Email
    email = notify.get("email")
    if email:
        try:
            send_email(email, f"TSLP Alert: {alert.get('symbol')} {alert.get('direction')} {alert.get('value')}", 
                       f"Alert triggered.\n\nCurrent value: {current}\nAlert: {json.dumps(alert, indent=2)}")
        except Exception as e:
            errors.append(str(e))
    # SMS via Twilio
    sms = notify.get("sms")
    if sms and TwilioClient:
        try:
            send_sms(sms, f"TSLP Alert: {alert.get('symbol')} now {current} (alert {alert.get('direction')} {alert.get('value')})")
        except Exception as e:
            errors.append(str(e))
    if errors:
        raise Exception("; ".join(errors))
    return True

def send_email(to_email, subject, body):
    # SMTP configuration via env vars
    SMTP_HOST = os.getenv("SMTP_HOST")
    SMTP_PORT = int(os.getenv("SMTP_PORT","587"))
    SMTP_USER = os.getenv("SMTP_USER")
    SMTP_PASS = os.getenv("SMTP_PASS")
    FROM = os.getenv("EMAIL_FROM", SMTP_USER)

    if not SMTP_HOST or not SMTP_USER or not SMTP_PASS:
        raise Exception("SMTP not configured. Set SMTP_HOST, SMTP_USER, SMTP_PASS env vars.")

    msg = EmailMessage()
    msg["Subject"] = subject
    msg["From"] = FROM
    msg["To"] = to_email
    msg.set_content(body)

    with smtplib.SMTP(SMTP_HOST, SMTP_PORT) as s:
        s.starttls()
        s.login(SMTP_USER, SMTP_PASS)
        s.send_message(msg)

def send_sms(number, body):
    if not TwilioClient:
        raise Exception("Twilio library not installed.")
    TW_SID = os.getenv("TWILIO_SID")
    TW_TOKEN = os.getenv("TWILIO_TOKEN")
    TW_FROM = os.getenv("TWILIO_FROM")
    if not (TW_SID and TW_TOKEN and TW_FROM):
        raise Exception("Twilio env vars missing.")
    client = TwilioClient(TW_SID, TW_TOKEN)
    client.messages.create(body=body, from_=TW_FROM, to=number)

if __name__=="__main__":
    # Production should use gunicorn; this is for local dev
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", "5000")), debug=(os.getenv("FLASK_ENV")=="development"))
