#!/bin/bash
# quick local run script
export FLASK_ENV=development
export USE_MOCK=1
python app.py
